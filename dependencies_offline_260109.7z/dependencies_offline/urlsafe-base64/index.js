
module.exports = require('./lib/urlsafe-base64');